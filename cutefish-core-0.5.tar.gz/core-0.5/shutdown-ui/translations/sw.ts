<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="sw">
<context>
    <name>main</name>
    <message>
        <location filename="../main.qml" line="74"/>
        <source>Shutdown</source>
        <translation>Zima</translation>
    </message>
    <message>
        <location filename="../main.qml" line="82"/>
        <source>Reboot</source>
        <translation>Wakisha tena</translation>
    </message>
    <message>
        <location filename="../main.qml" line="90"/>
        <source>Logout</source>
        <translation>Toka Nje</translation>
    </message>
    <message>
        <location filename="../main.qml" line="98"/>
        <source>Lock screen</source>
        <translation>Funga skrini</translation>
    </message>
    <message>
        <location filename="../main.qml" line="106"/>
        <source>Suspend</source>
        <translation>Simamisha</translation>
    </message>
</context>
</TS>
