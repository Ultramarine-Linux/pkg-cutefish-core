<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="fr">
<context>
    <name>main</name>
    <message>
        <location filename="../main.qml" line="67"/>
        <source>Shutdown</source>
        <translation>Éteindre</translation>
    </message>
    <message>
        <location filename="../main.qml" line="75"/>
        <source>Reboot</source>
        <translation>Redémarrer</translation>
    </message>
    <message>
        <location filename="../main.qml" line="83"/>
        <source>Logout</source>
        <translation>Se déconnecter</translation>
    </message>
    <message>
        <location filename="../main.qml" line="91"/>
        <source>Suspend</source>
        <translation>Suspendre</translation>
    </message>
</context>
<context>
    <name></name>
</context>
</TS>
