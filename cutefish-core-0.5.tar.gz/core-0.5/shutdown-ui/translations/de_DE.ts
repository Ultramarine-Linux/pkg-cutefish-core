<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="de_DE" sourcelanguage="de_DE">
<context>
    <name>main</name>
    <message>
        <location filename="../main.qml" line="67"/>
        <source>Shutdown</source>
        <translation>Herunterfahren</translation>
    </message>
    <message>
        <location filename="../main.qml" line="75"/>
        <source>Reboot</source>
        <translation>Neustart</translation>
    </message>
    <message>
        <location filename="../main.qml" line="83"/>
        <source>Logout</source>
        <translation>Abmelden</translation>
    </message>
    <message>
        <location filename="../main.qml" line="91"/>
        <source>Suspend</source>
        <translation>Bereitschaft</translation>
    </message>
</context>
<context>
    <name></name>
</context>
</TS>
