<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="zh_TW" sourcelanguage="de_DE">
<context>
    <name>main</name>
    <message>
        <location filename="../main.qml" line="67"/>
        <source>Password</source>
        <translation>密碼</translation>
    </message>
    <message>
        <location filename="../main.qml" line="94"/>
        <source>Done</source>
        <translation>完成</translation>
    </message>
    <message>
        <location filename="../main.qml" line="86"/>
        <source>Cancel</source>
        <translation>取消</translation>
    </message>
</context>
</TS>
