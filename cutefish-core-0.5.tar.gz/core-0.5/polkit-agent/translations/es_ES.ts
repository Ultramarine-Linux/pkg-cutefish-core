<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="es" sourcelanguage="de_DE">
<context>
    <name>main</name>
    <message>
        <location filename="../main.qml" line="67"/>
        <source>Password</source>
        <translation>Contraseña</translation>
    </message>
    <message>
        <location filename="../main.qml" line="94"/>
        <source>Done</source>
        <translation>Terminado</translation>
    </message>
    <message>
        <location filename="../main.qml" line="86"/>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
</context>
</TS>
