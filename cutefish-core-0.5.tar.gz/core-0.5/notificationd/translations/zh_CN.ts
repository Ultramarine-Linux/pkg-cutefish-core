<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1">
<context>
    <name>NotificationWindow</name>
    <message>
        <location filename="../qml/NotificationWindow.qml" line="91"/>
        <source>Notification Center</source>
        <translation>通知中心</translation>
    </message>
    <message>
        <location filename="../qml/NotificationWindow.qml" line="123"/>
        <source>No notifications</source>
        <translation>无通知</translation>
    </message>
</context>
</TS>
