<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1">
<context>
    <name>NotificationWindow</name>
    <message>
        <location filename="../qml/NotificationWindow.qml" line="91"/>
        <source>Notification Center</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/NotificationWindow.qml" line="123"/>
        <source>No notifications</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
