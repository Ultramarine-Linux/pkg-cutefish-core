<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="lv">
<context>
    <name>main</name>
    <message>
        <location filename="../main.qml" line="74"/>
        <source>Shutdown</source>
        <translation>Izslēgt</translation>
    </message>
    <message>
        <location filename="../main.qml" line="82"/>
        <source>Reboot</source>
        <translation>Restartēt</translation>
    </message>
    <message>
        <location filename="../main.qml" line="90"/>
        <source>Logout</source>
        <translation>Izrakstīties</translation>
    </message>
    <message>
        <location filename="../main.qml" line="98"/>
        <source>Lock screen</source>
        <translation>Bloķēt ekrānu</translation>
    </message>
    <message>
        <location filename="../main.qml" line="106"/>
        <source>Suspend</source>
        <translation>Aizmidzināt</translation>
    </message>
</context>
</TS>
