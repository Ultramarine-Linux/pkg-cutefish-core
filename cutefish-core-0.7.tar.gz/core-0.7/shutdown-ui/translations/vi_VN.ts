<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="vi">
<context>
    <name>main</name>
    <message>
        <location filename="../main.qml" line="74"/>
        <source>Shutdown</source>
        <translation>Tắt nguồn</translation>
    </message>
    <message>
        <location filename="../main.qml" line="82"/>
        <source>Reboot</source>
        <translation>Khởi động lại</translation>
    </message>
    <message>
        <location filename="../main.qml" line="90"/>
        <source>Logout</source>
        <translation>Đăng xuất</translation>
    </message>
    <message>
        <location filename="../main.qml" line="98"/>
        <source>Lock screen</source>
        <translation>Khóa màn hình</translation>
    </message>
    <message>
        <location filename="../main.qml" line="106"/>
        <source>Suspend</source>
        <translation>Ngủ đông</translation>
    </message>
</context>
</TS>
