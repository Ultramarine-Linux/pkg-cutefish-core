<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="zh_CN">
<context>
    <name>main</name>
    <message>
        <location filename="../main.qml" line="74"/>
        <source>Shutdown</source>
        <translation>关机</translation>
    </message>
    <message>
        <location filename="../main.qml" line="82"/>
        <source>Reboot</source>
        <translation>重新启动</translation>
    </message>
    <message>
        <location filename="../main.qml" line="90"/>
        <source>Logout</source>
        <translation>注销</translation>
    </message>
    <message>
        <location filename="../main.qml" line="98"/>
        <source>Lock screen</source>
        <translation>锁屏</translation>
    </message>
    <message>
        <location filename="../main.qml" line="106"/>
        <source>Suspend</source>
        <translation>休眠</translation>
    </message>
</context>
</TS>
