<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="ta">
<context>
    <name>main</name>
    <message>
        <location filename="../main.qml" line="67"/>
        <source>Shutdown</source>
        <translation>நிறுத்தவும்</translation>
    </message>
    <message>
        <location filename="../main.qml" line="75"/>
        <source>Reboot</source>
        <translation>மீண்டும் துவக்கவும்</translation>
    </message>
    <message>
        <location filename="../main.qml" line="83"/>
        <source>Logout</source>
        <translation>வெளியேறு</translation>
    </message>
    <message>
        <location filename="../main.qml" line="91"/>
        <source>Suspend</source>
        <translation>இடைநிறுத்து</translation>
    </message>
</context>
</TS>
