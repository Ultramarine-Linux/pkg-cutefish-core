<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="mg">
<context>
    <name>main</name>
    <message>
        <location filename="../main.qml" line="74"/>
        <source>Shutdown</source>
        <translation>Vonoina</translation>
    </message>
    <message>
        <location filename="../main.qml" line="82"/>
        <source>Reboot</source>
        <translation>Averina alefa</translation>
    </message>
    <message>
        <location filename="../main.qml" line="90"/>
        <source>Logout</source>
        <translation>Mivoaka</translation>
    </message>
    <message>
        <location filename="../main.qml" line="98"/>
        <source>Lock screen</source>
        <translation>Hidiana ny ecran</translation>
    </message>
    <message>
        <location filename="../main.qml" line="106"/>
        <source>Suspend</source>
        <translation>Ajanona</translation>
    </message>
</context>
</TS>
