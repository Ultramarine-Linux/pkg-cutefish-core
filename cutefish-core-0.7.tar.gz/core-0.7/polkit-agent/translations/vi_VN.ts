<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="vi" sourcelanguage="de_DE">
<context>
    <name>main</name>
    <message>
        <location filename="../main.qml" line="67"/>
        <source>Password</source>
        <translation>Mật khẩu</translation>
    </message>
    <message>
        <location filename="../main.qml" line="94"/>
        <source>Done</source>
        <translation>Đã hoàn thành</translation>
    </message>
    <message>
        <location filename="../main.qml" line="86"/>
        <source>Cancel</source>
        <translation>Đã hủy</translation>
    </message>
</context>
</TS>
