<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="uz" sourcelanguage="de_DE">
<context>
    <name>main</name>
    <message>
        <location filename="../main.qml" line="67"/>
        <source>Password</source>
        <translation>Hahfiy so&apos;z</translation>
    </message>
    <message>
        <location filename="../main.qml" line="94"/>
        <source>Done</source>
        <translation>Bajarildi</translation>
    </message>
    <message>
        <location filename="../main.qml" line="86"/>
        <source>Cancel</source>
        <translation>Bekor</translation>
    </message>
</context>
</TS>
