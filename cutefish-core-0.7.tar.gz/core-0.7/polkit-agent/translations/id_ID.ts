<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="id" sourcelanguage="de_DE">
<context>
    <name>main</name>
    <message>
        <location filename="../main.qml" line="67"/>
        <source>Password</source>
        <translation>Sandi</translation>
    </message>
    <message>
        <location filename="../main.qml" line="94"/>
        <source>Done</source>
        <translation>Selesai</translation>
    </message>
    <message>
        <location filename="../main.qml" line="86"/>
        <source>Cancel</source>
        <translation>Batal</translation>
    </message>
</context>
</TS>
